@echo off
echo DISM /RestoreHealth en cours...
DISM /Online /Cleanup-Image /RestoreHealth
echo OK.
