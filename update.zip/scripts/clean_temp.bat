@echo off
echo Suppression des fichiers temporaires...
del /q /f /s %temp%\*
del /q /f /s C:\Windows\Temp\*
echo OK.
