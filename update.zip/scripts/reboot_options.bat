@echo off
cls
echo 1 - Redémarrage normal
echo 2 - Mode sans échec
echo 3 - Mode réparation
set /p r=Choix : 

if "%r%"=="1" shutdown /r /t 0
if "%r%"=="2" shutdown /r /o /t 0
if "%r%"=="3" shutdown /r /o /t 0
