@echo off
ipconfig /flushdns
echo DNS vidé.
