@echo off
netsh winsock reset
netsh int ip reset
echo Réseau réinitialisé.
