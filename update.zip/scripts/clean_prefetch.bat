@echo off
echo Nettoyage Prefetch...
del /q /f /s C:\Windows\Prefetch\*
echo OK.
