@echo off
echo Nettoyage Windows Update...
net stop wuauserv
net stop bits
del /q /f /s C:\Windows\SoftwareDistribution\Download\*
net start wuauserv
net start bits
echo OK.
