@echo off
echo Vidage de la corbeille...
powershell.exe -command "Clear-RecycleBin -Force"
echo OK.
