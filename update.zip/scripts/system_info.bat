@echo off
systeminfo
echo.
wmic logicaldisk get size,freespace,caption
echo.
pause
