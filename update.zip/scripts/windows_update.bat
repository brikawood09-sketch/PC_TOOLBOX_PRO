@echo off
echo Recherche des mises à jour...
powershell.exe -command "Get-WindowsUpdate"
pause
