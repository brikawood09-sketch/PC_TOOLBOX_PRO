@echo off
chcp 65001 >nul
title PC_TOOLBOX_PRO - MENU GENERAL
color 0A

:: Chemin du dossier principal
set "ROOT=%~dp0"
set "UPDATER=%ROOT%updater"

:: Fichiers
set "LOCAL_VERSION=%ROOT%version.txt"
set "REMOTE_VERSION=%UPDATER%\remote_version.txt"
set "UPDATE_ENGINE=%UPDATER%\update_engine.bat"

:: URL de base GitHub
set /p URL_BASE=<"%UPDATER%\update_source_url.txt"

echo ===========================================
echo        PC_TOOLBOX_PRO - MENU GENERAL
echo ===========================================
echo.

:: Vérifier si version.txt existe
if not exist "%LOCAL_VERSION%" (
    echo ERREUR : version.txt introuvable !
    pause
    exit /b
)

:: Lire version locale
set /p LOCAL=<"%LOCAL_VERSION%"
echo Version locale : %LOCAL%
echo.

:: Télécharger version distante
powershell -command "Invoke-WebRequest '%URL_BASE%version.txt' -UseBasicParsing -OutFile '%REMOTE_VERSION%'"

if not exist "%REMOTE_VERSION%" (
    echo ERREUR : Impossible de récupérer la version distante !
    pause
    exit /b
)

set /p REMOTE=<"%REMOTE_VERSION%"
echo Version distante : %REMOTE%
echo.

:: Comparaison
if "%LOCAL%"=="%REMOTE%" (
    echo Votre PC_TOOLBOX_PRO est déjà à jour.
    echo.
    goto MENU
)

echo Nouvelle version disponible !
echo Téléchargement de la mise à jour...
echo.

:: Lancer le moteur de mise à jour
call "%UPDATE_ENGINE%"

goto MENU

:MENU
echo ===========================================
echo              MENU GENERAL
echo ===========================================
echo 1 - Nettoyage rapide
echo 2 - Nettoyage complet (avec rapport)
echo 3 - Réparation Windows
echo 4 - Informations système
echo 5 - Réseau
echo 6 - Mise à jour Windows
echo 7 - Redémarrage avancé
echo U - Mettre à jour PC_TOOLBOX_PRO
echo Q - Quitter
echo.
set /p CHOIX="Votre choix : "

if "%CHOIX%"=="2" goto NETTOYAGE_COMPLET
if "%CHOIX%"=="Q" exit /b

goto MENU

:: ============================================================
:: MODULE D — NETTOYAGE COMPLET + RAPPORT PRO
:: ============================================================

:NETTOYAGE_COMPLET
cls
echo Nettoyage complet en cours...
echo.

:: Création du dossier LOGS si absent
if not exist "%ROOT%PC_TOOLBOX_LOGS" (
    mkdir "%ROOT%PC_TOOLBOX_LOGS"
)

:: Fichier de log avec date/heure
set LOGFILE=%ROOT%PC_TOOLBOX_LOGS\nettoyage_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%_%TIME:~0,2%%TIME:~3,2%%TIME:~6,2%.log

echo Début du nettoyage : %DATE% %TIME% > "%LOGFILE%"
echo ---------------------------------------- >> "%LOGFILE%"

:: Nettoyage des fichiers temporaires
echo Suppression des fichiers temporaires...
powershell -command ^
    "$files = Get-ChildItem $env:TEMP -Recurse -ErrorAction SilentlyContinue;" ^
    "$count = $files.Count;" ^
    "$ignored = 0;" ^
    "foreach ($f in $files) { try { Remove-Item $f.FullName -Force -Recurse -ErrorAction Stop } catch { $ignored++ } }" ^
    "Add-Content '%LOGFILE%' ('Fichiers trouvés : ' + $count);" ^
    "Add-Content '%LOGFILE%' ('Fichiers supprimés : ' + ($count - $ignored));" ^
    "Add-Content '%LOGFILE%' ('Fichiers ignorés : ' + $ignored);"

echo Nettoyage des fichiers temporaires terminé.
echo.

:: Nettoyage Windows Update
echo Nettoyage Windows Update...
powershell -command ^
    "try { Stop-Service wuauserv -Force -ErrorAction SilentlyContinue } catch {}" ^
    "try { Stop-Service bits -Force -ErrorAction SilentlyContinue } catch {}" ^
    "try { Remove-Item 'C:\Windows\SoftwareDistribution\Download\*' -Force -Recurse -ErrorAction SilentlyContinue } catch {}" ^
    "try { Start-Service wuauserv -ErrorAction SilentlyContinue } catch {}" ^
    "Add-Content '%LOGFILE%' 'Nettoyage Windows Update : OK'"

echo Nettoyage Windows Update terminé.
echo.

:: Nettoyage corbeille silencieux
echo Vidage de la corbeille...
powershell -command ^
    "try { Clear-RecycleBin -Force -ErrorAction SilentlyContinue } catch {}" ^
    "Add-Content '%LOGFILE%' 'Corbeille vidée : OK'"

echo Corbeille vidée.
echo.

:: Fin du rapport
echo Fin du nettoyage : %DATE% %TIME% >> "%LOGFILE%"
echo ---------------------------------------- >> "%LOGFILE%"

echo Nettoyage complet terminé !
echo Rapport généré :
echo %LOGFILE%
echo.
pause
goto MENU
