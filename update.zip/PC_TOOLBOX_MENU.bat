@echo off
title PC_TOOLBOX_PRO - Menu Principal
color 0A

REM --- Vérification de mise à jour ---
call PC_TOOLBOX_UPDATE.bat

:MENU
cls
echo ================================================
echo            PC_TOOLBOX_PRO - MENU GENERAL
echo ================================================
echo.
echo   1 - Nettoyage rapide
echo   2 - Nettoyage complet
echo   3 - Réparation Windows
echo   4 - Informations système
echo   5 - Réseau
echo   6 - Mise à jour Windows
echo   7 - Redémarrage avancé
echo   U - Mettre à jour PC_TOOLBOX_PRO
echo   0 - Quitter
echo.
set /p choix=Votre choix : 

if /i "%choix%"=="1" call scripts\clean_temp.bat & call scripts\clean_recycle.bat & pause & goto MENU
if /i "%choix%"=="2" call scripts\clean_temp.bat & call scripts\clean_recycle.bat & call scripts\clean_windows_update.bat & call scripts\clean_prefetch.bat & pause & goto MENU
if /i "%choix%"=="3" call scripts\repair_dism.bat & call scripts\repair_sfc.bat & pause & goto MENU
if /i "%choix%"=="4" call scripts\system_info.bat & pause & goto MENU
if /i "%choix%"=="5" call scripts\net_flushdns.bat & call scripts\net_reset.bat & pause & goto MENU
if /i "%choix%"=="6" call scripts\windows_update.bat & pause & goto MENU
if /i "%choix%"=="7" call scripts\reboot_options.bat & goto MENU
if /i "%choix%"=="U" call PC_TOOLBOX_UPDATE.bat & goto MENU
if "%choix%"=="0" exit

goto MENU
