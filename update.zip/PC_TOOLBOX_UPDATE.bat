@echo off
chcp 65001 >nul
title PC_TOOLBOX_PRO - MOTEUR DE MISE À JOUR
color 0A

set "ROOT=%~dp0"
set "UPDATER=%ROOT%updater"
set "LOCAL_VERSION=%ROOT%version.txt"
set "REMOTE_VERSION=%UPDATER%\remote_version.txt"
set "UPDATE_ZIP=%UPDATER%\update.zip"

echo ===========================================
echo        PC_TOOLBOX_PRO - MOTEUR DE MISE À JOUR
echo ===========================================
echo.

echo Téléchargement de la mise à jour...
powershell -command ^
    "try { Invoke-WebRequest '%URL_BASE%update.zip' -UseBasicParsing -OutFile '%UPDATE_ZIP%' } catch { exit 1 }"

if not exist "%UPDATE_ZIP%" (
    echo ERREUR : Le fichier update.zip n'a pas été téléchargé !
    pause
    exit /b
)

echo Extraction des fichiers...
powershell -command ^
    "try { Expand-Archive -Path '%UPDATE_ZIP%' -DestinationPath '%ROOT%' -Force } catch { exit 1 }"

echo Mise à jour terminée !
echo.

echo %REMOTE%>"%LOCAL_VERSION%"

del "%UPDATE_ZIP%" >nul 2>&1

echo Mise à jour appliquée avec succès.
echo.
exit /b
