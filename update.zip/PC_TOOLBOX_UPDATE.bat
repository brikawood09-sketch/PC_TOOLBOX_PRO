@echo off
title PC_TOOLBOX_PRO - Mise à jour
color 0A

setlocal EnableDelayedExpansion

echo ================================================
echo        PC_TOOLBOX_PRO - SYSTEME DE MISE A JOUR
echo ================================================
echo.

REM --- Charger l’URL GitHub ---
set "URL_BASE="
for /f "usebackq delims=" %%A in ("updater\update_source_url.txt") do set "URL_BASE=%%A"

if "%URL_BASE%"=="" (
    echo ERREUR : Impossible de lire update_source_url.txt
    pause
    exit /b
)

REM --- Lire version locale ---
set "LOCAL_VERSION="
for /f "usebackq delims=" %%A in ("version.txt") do set "LOCAL_VERSION=%%A"

echo Version locale : %LOCAL_VERSION%

REM --- Lire version distante ---
set "REMOTE_VERSION="
powershell -command "(Invoke-WebRequest '%URL_BASE%version.txt').Content" > updater\remote_version.txt

for /f "usebackq delims=" %%A in ("updater\remote_version.txt") do set "REMOTE_VERSION=%%A"

echo Version distante : %REMOTE_VERSION%
echo.

REM --- Comparaison ---
if "%LOCAL_VERSION%"=="%REMOTE_VERSION%" (
    echo Votre PC_TOOLBOX_PRO est déjà à jour.
    pause
    exit /b
)

echo Nouvelle version disponible !
echo Téléchargement de la mise à jour...
echo.

REM --- Télécharger update.zip ---
powershell -command "(Invoke-WebRequest '%URL_BASE%update.zip' -OutFile 'updater\update.zip')"

REM === Attendre que PowerShell libère le fichier ===
timeout /t 2 >nul

REM === Vérifier si le fichier est encore verrouillé ===
:check_lock
powershell -command "try { Remove-Item 'updater\update.zip' -ErrorAction Stop } catch { exit 1 }"
if %errorlevel%==1 (
    timeout /t 1 >nul
    goto check_lock
)

REM --- Extraire update.zip ---
powershell -command "Expand-Archive -Path 'updater\update.zip' -DestinationPath '.' -Force"

REM --- Mise à jour version ---
echo %REMOTE_VERSION% > version.txt

echo Mise à jour terminée !
echo.
pause
exit /b
